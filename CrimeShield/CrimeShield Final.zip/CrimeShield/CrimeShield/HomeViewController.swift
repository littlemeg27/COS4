//
//  ViewController.swift
//  CrimeShield
//
//  Created by Brenna Pavlinchak on 1/16/25.
//

import UIKit

class HomeViewController: UIViewController
{
    @IBAction func CreateReportButton(_ sender: Any)
    {
        
    }

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       
    
    }


}

